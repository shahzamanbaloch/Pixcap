describe('Point Of Sell Website', () => {

    before(function() {
          cy.fixture('userdetails').then(function(data)
             {
            this.data=data
            });
            });

   
    // it('login user and password Negative', function()  {
    //     cy.visit('https://www.techwhizz.co.uk/modernpos/')
    //     cy.get("[name='username']").type(this.data.email)
    //     cy.get("[name='password']").type(this.data.wrongpassword)
    //     cy.get("button#login-btn").click()
    //     cy.get(".toast-message").contains('Username or Password is invalid').should('be.visible')
        
    // })

   
    it('login user and password postive', function() {
        cy.visit('https://www.techwhizz.co.uk/modernpos/')
        cy.get("[name='username']").type(this.data.email)
        cy.get("[name='password']").type(this.data.rightpassword)
        cy.get("button#login-btn").click()
        cy.visit('https://www.techwhizz.co.uk/modernpos/store_select.php?redirect_to=')
        cy.get("ul.list-unstyled > li:nth-of-type(1) .store-name").click()
        cy.get("span.logo-lg > [title='Techwhizz']").contains('Techwhizz').should('be.visible')
  
    })

   
    
  })