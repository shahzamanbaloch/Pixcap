describe('My First Test', function (){
    it('Does not do much!', function(){
      cy.visit('https://www.techwhizz.co.uk/modernpos/');
    })
  })