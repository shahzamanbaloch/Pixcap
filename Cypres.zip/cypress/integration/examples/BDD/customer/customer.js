import { Given ,When, Then, And} from "cypress-cucumber-preprocessor/steps";

Given('I open modernpos website', function()  {
    cy.visit('https://www.techwhizz.co.uk/modernpos/')
    
  })
  
  Then('user login website', function()  {
      cy.get("[name='username']").type('sajjad.sahito60@gmail.com')
      cy.get("[name='password']").type('indus658_morderp')
      cy.get("button#login-btn").click()
      cy.visit('https://www.techwhizz.co.uk/modernpos/store_select.php?redirect_to=')
      cy.get("ul.list-unstyled > li:nth-of-type(1) .store-name").click()
    
    })
   
    Then('user click on customer menu', function()  {
        cy.get(".sidebar-menu > .treeview > [href='customer.php']").click()
    })

    Then('user click on add customer', function()  {
        cy.get(".sidebar-menu > li:nth-of-type(8) li:nth-of-type(1) > a").click()
        cy.get('#customer_name').type('shaz')
        cy.get('#credit_balance').clear()
        cy.get('#credit_balance').type(5000)
        cy.get('#customer_mobile').type(123456789)
        cy.get('#dob').click()
        cy.get('tr:nth-of-type(3) > td:nth-of-type(6)').click()
        cy.get('#customer_email').clear()
        cy.get('#customer_email').type('shaz@gmail.com')
        cy.get("[aria-labelledby='select2-customer_sex-container'] > .select2-selection__rendered").click()
        cy.get('.select2-results__option--highlighted').click()
        cy.get('#customer_age').type(40)
        cy.get('#customer_address').type('England London United Kingdom')
        cy.get('#customer_city').type('London')
        cy.get('#customer_state').type('England')
        cy.get("[aria-labelledby='select2-customer_country-container'] > .select2-selection__arrow").click()
        cy.get(".select2-search__field").type('united')
        cy.get(".select2-results__options > li:nth-of-type(2)").click()
        cy.get('#create-customer-submit').click()
        cy.wait(1000)
    })

    Then('user view customer', function()  {
        cy.get(".sidebar-menu .treeview-menu [href='customer.php']").click()
        cy.get('.odd > td:nth-of-type(2)').contains('shaz').should('be.visible')
    });


    Then('user Edit the customer', function()  {
        cy.get(".sidebar-menu .treeview-menu [href='customer.php']").click()
        cy.get("#edit-customer").click()
        cy.get('.modal-title').contains('shaz').should('be.visible')
        cy.get("[value='shaz']").clear()
        cy.get("[value='shaz']").type('shazaman Rind')
        cy.get("#customer-update").click()
        cy.get(".swal-button--confirm").click()
        
        
    });

    Then('user Delete the customer', function()  {
        cy.get(".sidebar-menu .treeview-menu [href='customer.php']").click()
        cy.get("#delete-customer").click()
        cy.get('.radio > .select2 > .selection > .select2-selection > .select2-selection__arrow').click({ force: true })
        
        cy.get("[aria-selected='false']").click()
        cy.get('#customer-delete').click()
        cy.get('.swal-button').click()
        
    });
    
