import { Given ,When, Then, And} from "cypress-cucumber-preprocessor/steps";


Given('I open modernpos website', function()  {
  cy.visit('https://www.techwhizz.co.uk/modernpos/')
  
})



Then('user clicks input email', function()  {
    cy.get("[name='username']").type('sajjad.sahito60@gmail.com')
  })
  

  Then('user clicks input password', function()  {
    cy.get("[name='password']").type('indus658_morderp')
  })

  Then('user click on signin button', function()  {
    
    cy.get("button#login-btn").click()
    cy.visit('https://www.techwhizz.co.uk/modernpos/store_select.php?redirect_to=')
    cy.get("ul.list-unstyled > li:nth-of-type(1) .store-name").click()
    // cy.get("span.logo-lg > [title='Techwhizz']").contains('Techwhizz').should('be.visible')
    cy.clearLocalStorage()
  })

  Then('user click on product menu', function()  {
    cy.get(".sidebar-menu > .treeview > [href='product.php']").click()
  })

  Then('user click on add product', function()  {
    cy.get('.active > .treeview-menu > :nth-child(2) > a').click()
    cy.get('#p_name').type('Testing123')
    cy.get('#random_num').click()
    
   
    cy.get("[aria-labelledby='select2-category_id-container'] > .select2-selection__arrow").click()
    cy.get(".select2-results__options > li:nth-of-type(4)").click()
 
    cy.get("[aria-labelledby='select2-sup_id-container'] > .select2-selection__arrow").click()
    cy.get(".select2-search__field").type('Byco')
    cy.get('.select2-results__option').click()

    cy.get("[aria-labelledby='select2-brand_id-container'] > .select2-selection__rendered").click()
    cy.get('.select2-search__field').type('No Brand')
    cy.get('.select2-results__option').click()


    cy.get("[aria-labelledby='select2-unit_id-container'] > .select2-selection__rendered").click()
    cy.get('.select2-results__options > li:nth-of-type(2)').click()

    cy.get('#sell_price').type('130')

    cy.get("[aria-labelledby='select2-taxrate_id-container'] > .select2-selection__rendered").click()
    cy.get('.select2-results__options > li:nth-of-type(2)').click()
    
    cy.get('#alert_quantity').clear()
    cy.get('#alert_quantity').type(100)
  
    cy.get('.mce-i-code').click()
    cy.get('.mce-textbox').type('This is for testing')
    cy.get(".mce-primary > [role='presentation']").click()

    
    cy.get('#create-product-submit').click()

    
    // cy.get('table#product-product-list tr').contains('LPG5').should('be.visible')
    // cy.get('table#product-product-list tr').contains('LPG5').should('be.visible')
  
 
  })

  
  Then('user edit product', function()  {
    // cy.reload()
    cy.wait(1000)
    cy.get('.edit-product').should('exist').click()
    cy.get('h3#modal-title').contains('Testing123').should('be.visible')
    cy.get("[value='Testing123']").clear()
    cy.get("[value='Testing123']").type('Testing1234')
 
   cy.get('#product-update-submit').click()
   cy.get('.swal-button--confirm').click()
  
  
});

Then('user delete product', function()  {
  cy.get('.product-delete').should('be.visible')
  cy.get('.product-delete').click({force: true})
  cy.get('#product-delete-submit').click()
  cy.wait(300)
  cy.get('button.swal-button.swal-button--confirm').click({force: true})
});

after(() => {

  cy.get('#logout').click()
  cy.get(':nth-child(2) > .swal-button').click()

})



