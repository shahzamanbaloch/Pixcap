import { Given ,When, Then, And} from "cypress-cucumber-preprocessor/steps";

// Given('I open nbs website', function()  {
//   cy.request({


//   })
// })

before(function() {
    cy.fixture('userdetails').then(function(data)
       {
      this.data=data
      });
      });

Given('I open nbs website', function()  {
  cy.visit('https://app-test.nimbus.thenbs.cloud/')
  cy.clearCookies()

//   cy.get('h1.ng-tns-c86-0').contains('NBS Chorus').should('be.visible')
})


Then('user click on sign in button', function()  {
  cy.get('#loginButton').contains('Sign in').should('be.visible')
  cy.get('#loginButton').click()
})

And('user clicks input fields', function()  {
cy.get('input#Email').should('be.enabled')
cy.get('input#Email').type('skrb00@outlook.com')
cy.get('input#Password').should('be.enabled')
 cy.get('input#Password').type('zainab@1')
})


Then('user click on signin button',function(){
  cy.get('.submit-button').contains('Sign in').should('be.enabled')
  cy.get('.submit-button').click()
  cy.wait(1000)
})

Then('user create project',function(){
  cy.get('div.grid-controls > #create-project-button').contains('Create project ').should('be.visible')
  cy.get('div.grid-controls > #create-project-button').click()

  cy.get('#code-input').should('be.enabled')
  cy.get('#code-input').type('qaproject123699')

  cy.get('#title-input').should('be.enabled')
  cy.get('#title-input').type('DigitalUniversity')

  cy.get('div.two-column-2-2 label:nth-of-type(3) .mat-form-field-flex').click()
  // cy.get('div.two-column-2-2 label:nth-of-type(3) mat-icon:nth-of-type(1)').type('New Build')
  cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(2) > .mat-option-text').click()

  cy.get('#client-input').should('be.enabled')
  cy.get('#client-input').type('Uk')

  cy.get('#dataSharingChange').contains('Change').should('be.visible')
  cy.get('#dataSharingChange').click()
  cy.get("div[aria-posinset='4'] > .mat-tab-label-content").click()
  cy.get("div.mat-slide-toggle-bar").click()

  cy.get("span.mat-button-wrapper").contains('Close').click()
  
  // cy.get('input[_ngcontent-pjx-c230]').should('be.enabled')
  cy.get('#mat-input-12').click()
  //cy.get('#mat-input-12').type('Use')
  cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(8) > .mat-option-text > span').click()
  

  // cy.get('div.two-column-2-2 label:nth-of-type(6) .mat-form-field-infix').should('be.enabled')
  cy.get('div.two-column-2-2 label:nth-of-type(6) input:nth-of-type(1)').click()
  // cy.get('div.two-column-2-2 label:nth-of-type(6) .mat-form-field-infix').type('Education')
  cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(3) > .mat-option-text').click()
  

  //cy.get('div.nbs-currency-value-field .mat-form-field-infix').should('be.enabled')
  cy.get('#budget').clear()
  cy.get('#budget').type(500)


  cy.get('div.two-column-2-2 label:nth-of-type(7) input:nth-of-type(1)').click()
  // cy.get('div.two-column-2-2 label:nth-of-type(7) input:nth-of-type(1)').type(' Traditional')
  cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(5) > .mat-option-text').click()

  cy.get('.mat-datepicker-input').should('be.enabled')
  cy.get('.mat-datepicker-input').click()
  cy.get(".mat-calendar-body-today").click()

  cy.get('#project-description-input').should('be.enabled')
  cy.get('#project-description-input').type('This is a for test Project')

  cy.get('footer.footer > #project-details-form-save').should('be.enabled')
  cy.get('footer.footer > #project-details-form-save').click()


})



Then('user verify the project title and clicks on project title',function(){

  cy.get("h2[title='DigitalUniversity']").contains('DigitalUniversity').should('be.visible').click()

})

Then('user click on teammember button',function(){

    cy.get('.mat-tab-links > .ng-star-inserted > .ng-tns-c389-42').contains('Team Members').should('be.visible').click()
  
  })

