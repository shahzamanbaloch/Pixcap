const assert = require('assert');
// var credentials = require('./credentials.json')
var Max_TimeOut = 200000;
var locator;
var expected = protractor.ExpectedConditions;
var productPrice;
module.exports = function () {
    browser.waitForAngularEnabled(false);
    /********************************************************************************************************************************************/

    /********************************************************************************************************************************************/
    this.Given(/^User launches "([^""]*)" website$/, async function (url) {
        // switch (url) {
        //     case 'Amazon.co.uk':
        //         url = 'https://www.amazon.co.uk/';
        //         break;
        //     default:
        //         console.log('No value')
        // }
        url = 'https://www.techwhizz.co.uk/modernpos/';
        await browser.get(url);
        //await browser.get(url);
    });

    // this.When(/^User inputs "([^""]*)"$/, async function (inputData) {
    //     switch (inputData) {

    //         case 'Username':
    //             inputData = element(by.id("ap_email"));
    //             userInput = credentials.username;
    //             break;

    //         case 'Password':
    //             inputData = element(by.id("ap_password"));
    //             userInput = credentials.password;
    //             break;

    //         default:
    //             console.log('No value')
    //     }

    //     await browser.wait(expected.visibilityOf(inputData), Max_TimeOut);
    //     await inputData.sendKeys(userInput);

    // });

}