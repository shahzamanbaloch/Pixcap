
import { Given ,When, Then, And} from "cypress-cucumber-preprocessor/steps";

import login from '../pom/login';
import project from '../pom/createproject';
import editproject from '../pom/edit_project';
import deleteproject from '../pom/deleteproject';

const loginpage = new login();
const createproject = new project();
const editprojectlatest = new editproject();
const delproject = new deleteproject();


before(function() {
    cy.fixture('userdetails').then(function(data)
       {
      this.data=data
      });
      });

Given('I open nbs website', function()  {
  cy.visit('https://app-test.nimbus.thenbs.cloud/')

})


Then('user click on sign in button', function()  {
  cy.get('#loginButton').contains('Sign in').should('be.visible')
  cy.get('#loginButton').click()
})

And('user clicks input fields', function()  {
    loginpage.getemail()
    loginpage.getpassword()
})


Then('user click on signin button',function(){
    loginpage.getsignbutton()
})

Then('user create project',function(){

    createproject.createbutton()
    createproject.codeinput()
    createproject.titleinput()
    createproject.projecttype()
    createproject.clientinput()
    createproject.datasharing()
    createproject.typetrophy()
    createproject.educationtype()
    createproject.currenyinput()
    createproject.tradition()
    createproject.datapicker()
    createproject.description()
    createproject.savebutton()
})


Then('user edit the project',function(){
  editprojectlatest.clickeditbtn()
  editprojectlatest.editinputtitle()
  editprojectlatest.editbuget()
  editprojectlatest.editchecktitle()
  
})



Then('user delete the project',function(){
  delproject.deletepro()

})