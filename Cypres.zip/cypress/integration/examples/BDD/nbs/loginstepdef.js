
import { Given ,When, Then, And} from "cypress-cucumber-preprocessor/steps";


before(function() {
    cy.fixture('userdetails').then(function(data)
       {
      this.data=data
      });
      });

Given('I open nbs website', function()  {
  cy.visit('https://app-test.nimbus.thenbs.cloud/')

})


Then('user click on sign in button', function()  {
  cy.get('#loginButton').contains('Sign in').should('be.visible')
  cy.get('#loginButton').click()
})

And('user clicks input fields', function()  {
cy.get('input#Email').should('be.enabled')
cy.get('input#Email').type('ribae.webdriver@gmail.com')
cy.get('input#Password').should('be.enabled')
 cy.get('input#Password').type('password')
})


Then('user click on signin button',function(){
  cy.get('.submit-button').contains('Sign in').should('be.enabled')
  cy.get('.submit-button').click()
  cy.wait(1000)
})

Then('user create project',function(){
  cy.get('div.grid-controls > #create-project-button').contains('Create project ').should('be.visible')
  cy.get('div.grid-controls > #create-project-button').click()

  // cy.get('#code-input').should('be.enabled')
  cy.get('#code-input').type('q123445555')

  // cy.get('#title-input').should('be.enabled')
  cy.get('#title-input').type('DigitalUniversity12')

  cy.get('div.two-column-2-2 label:nth-of-type(3) .mat-form-field-flex').click()
  // cy.get('div.two-column-2-2 label:nth-of-type(3) mat-icon:nth-of-type(1)').type('New Build')
  cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(2) > .mat-option-text').click()

  cy.get('#client-input').should('be.enabled')
  cy.get('#client-input').type('Uk')

  cy.get('#dataSharingChange').contains('Change').should('be.visible')
  cy.get('#dataSharingChange').click()
  cy.get("div[aria-posinset='4'] > .mat-tab-label-content").click()
  cy.get("div.mat-slide-toggle-bar").click()

  // cy.get("span.mat-button-wrapper").contains('Close').click()
  
  // // cy.get('input[_ngcontent-pjx-c230]').should('be.enabled')
  // cy.get('#mat-input-12').click()
  // //cy.get('#mat-input-12').type('Use')
  // cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(8) > .mat-option-text > span').click()
  

  // // cy.get('div.two-column-2-2 label:nth-of-type(6) .mat-form-field-infix').should('be.enabled')
  // cy.get('div.two-column-2-2 label:nth-of-type(6) input:nth-of-type(1)').click()
  // // cy.get('div.two-column-2-2 label:nth-of-type(6) .mat-form-field-infix').type('Education')
  // cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(3) > .mat-option-text').click()
  

  // cy.get('div.nbs-currency-value-field .mat-form-field-infix').should('be.enabled')
  // cy.get('#budget').clear()
  // cy.get('#budget').type(500)


  // cy.get('div.two-column-2-2 label:nth-of-type(7) input:nth-of-type(1)').click()
  // // cy.get('div.two-column-2-2 label:nth-of-type(7) input:nth-of-type(1)').type(' Traditional')
  // cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(5) > .mat-option-text').click()

  // cy.get('.mat-datepicker-input').should('be.enabled')
  // cy.get('.mat-datepicker-input').click()
  // cy.get("td[aria-label='March 21, 2021'] > .mat-calendar-body-cell-content").click()

  // cy.get('#project-description-input').should('be.enabled')
  // cy.get('#project-description-input').type('This is a for test Project')

  cy.get('footer.footer > #project-details-form-save').should('be.enabled')
  cy.get('footer.footer > #project-details-form-save').click()


})



Then('user verify the project title and clicks on project title',function(){
  cy.get('[row-index="23"] > .link-style > span').contains('DigitalUniversity').should('be.visible').click()
})


Then ('user add specification',function(){
  cy.get('#cy-add-spec').click()
  cy.get('.mat-form-field-type-mat-input .mat-form-field-infix').type('specification 001')
  cy.get('.mat-select-arrow-wrapper').click()
  cy.get('mat-option:nth-of-type(12) > .mat-option-text').click()
  cy.get('.footer > #save').click()
  cy.get('.mat-form-field-infix').type('ceramic')
  cy.get('#cy-content-search-icon').click()
  cy.get("[comp-id='1048'] .nbs-icon").click()
  cy.get(".navigator-trigger").click()
  cy.get("[title='Go to specification 001']").click()

}) 

// And('user go back to previous page',function(){

//   cy.get("a[title='Go to Projects']").click()
// })

// Then('user edit the project',function(){
//   cy.get("nbs-project-tile[aria-label='Open project called DigitalUniversity'] .mat-menu-trigger").click()
//   cy.get("button[data-cy='edit-action']").click()
//   cy.get('#code-input').click()
//   cy.get('#title-input').click()
//   cy.get('#title-input').clear()
//   cy.wait(3000)
//   // cy.get('#title-input').should('be.not.visibled')
//   cy.get("#title-input").type('EditDigitalProject')
//   cy.get('#budget').clear()
//   cy.get('#budget').type(1000)
//   cy.get('footer.footer > #project-details-form-save').should('be.enabled')
//   cy.get('footer.footer > #project-details-form-save').click()

//   cy.get('[aria-label="Open project called EditDigitalProject"] > .tile-content > .truncate').contains('EditDigitalProject').should('be.visible')
// })

// Then('user delete the project',function(){
//   cy.get("[aria-label='Open project called EditDigitalProject'] .mat-menu-trigger").click()
//   cy.get("[data-cy='delete-action']").click()

// })