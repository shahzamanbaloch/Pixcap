class deleteproject {

    deletepro(){
        cy.get("[aria-label='Open project called EditDigitalProject'] .mat-menu-trigger").click()
        cy.get("[data-cy='delete-action']").click()
    }
    
   

}

export default deleteproject;