class login {


    getemail(){
    cy.get('input#Email').should('be.enabled')
    cy.get('input#Email').type('skrb00@outlook.com')
     }

    getpassword(){
    cy.get('input#Password').should('be.enabled')
    cy.get('input#Password').type('zainab@1')
    }

    getsignbutton(){
    cy.get('.submit-button').contains('Sign in').should('be.enabled')
    cy.get('.submit-button').click()
    }

}

export default login;