class editproject {

    clickeditbtn(){
        cy.get("nbs-project-tile[aria-label='Open project called DigitalUniversity'] .mat-menu-trigger").click()
        cy.get("button[data-cy='edit-action']").click()
    }
    editinputtitle(){
        cy.get('#code-input').click()
         cy.get('#title-input').click()
         cy.get('#title-input').clear()
        cy.wait(3000)
        cy.get("#title-input").type('EditDigitalProject')
    }

    editbuget(){
        cy.get('#budget').clear()
        cy.get('#budget').type(1000)
        cy.get('footer.footer > #project-details-form-save').should('be.enabled')
        cy.get('footer.footer > #project-details-form-save').click()
    }

    editchecktitle(){
        cy.get('[aria-label="Open project called EditDigitalProject"] > .tile-content > .truncate').contains('EditDigitalProject').should('be.visible')
    }

}

export default editproject;