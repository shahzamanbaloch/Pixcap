class createproject {


    createbutton(){
      cy.get('div.grid-controls > #create-project-button').contains('Create project ').should('be.visible')
      cy.get('div.grid-controls > #create-project-button').click()
     }


     codeinput(){
         cy.get('#code-input').should('be.enabled')
         cy.get('#code-input').type('qaproject12367')
     }

     titleinput(){
         cy.get('#title-input').should('be.enabled')
         cy.get('#title-input').type('DigitalUniversity')
     }

     projecttype(){
      cy.get('div.two-column-2-2 label:nth-of-type(3) .mat-form-field-flex').click()
      // cy.get('div.two-column-2-2 label:nth-of-type(3) mat-icon:nth-of-type(1)').type('New Build')
      cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(2) > .mat-option-text').click()
     }

     clientinput(){
      cy.get('#client-input').should('be.enabled')
      cy.get('#client-input').type('Uk')
     }
     

     datasharing(){
      cy.get('#dataSharingChange').contains('Change').should('be.visible')
      cy.get('#dataSharingChange').click()
      cy.get("div[aria-posinset='4'] > .mat-tab-label-content").click()
      cy.get("div.mat-slide-toggle-bar").click()
      cy.get("span.mat-button-wrapper").contains('Close').click()
     }

    typetrophy(){
      cy.get('#mat-input-12').click()
      //cy.get('#mat-input-12').type('Use')
      cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(8) > .mat-option-text > span').click()
    }

    educationtype(){
         // cy.get('div.two-column-2-2 label:nth-of-type(6) .mat-form-field-infix').should('be.enabled')
         cy.get('div.two-column-2-2 label:nth-of-type(6) input:nth-of-type(1)').click()
         // cy.get('div.two-column-2-2 label:nth-of-type(6) .mat-form-field-infix').type('Education')
         cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(3) > .mat-option-text').click()
         
    }

    currenyinput(){
      cy.get('#budget').clear()
      cy.get('#budget').type(500)
    }

    tradition(){
      cy.get('div.two-column-2-2 label:nth-of-type(7) input:nth-of-type(1)').click()
      // cy.get('div.two-column-2-2 label:nth-of-type(7) input:nth-of-type(1)').type(' Traditional')
      cy.get('div.mat-autocomplete-panel > mat-option:nth-of-type(5) > .mat-option-text').click()
    }

    datapicker(){
      cy.get('.mat-datepicker-input').should('be.enabled')
      cy.get('.mat-datepicker-input').click()
      cy.get("td[aria-label='March 21, 2021'] > .mat-calendar-body-cell-content").click()
    }

    description(){   
      cy.get('#project-description-input').should('be.enabled')
      cy.get('#project-description-input').type('This is a for test Project')
    }

    savebutton(){   
      cy.get('footer.footer > #project-details-form-save').should('be.enabled')
      cy.get('footer.footer > #project-details-form-save').click()
   }
}

export default createproject;