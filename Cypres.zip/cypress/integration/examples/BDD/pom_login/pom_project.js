class pom_project {


    getemail(){
        cy.get("[name='username']").type('sajjad.sahito60@gmail.com')
         }
    
    getpassword(){
            cy.get("[name='password']").type('indus658_morderp')
        }
    
    getsignbutton(){
         
        cy.get("button#login-btn").click()
        cy.visit('https://www.techwhizz.co.uk/modernpos/store_select.php?redirect_to=')
        cy.get("ul.list-unstyled > li:nth-of-type(1) .store-name").click()
  
        }





}

export default pom_project;