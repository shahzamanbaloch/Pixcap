import { Given ,When, Then, And} from "cypress-cucumber-preprocessor/steps";
import pom_project from '../pom_login/pom_project';

const pom_project_page = new pom_project();

Given('I open modernpos website', function()  {
    cy.visit('https://www.techwhizz.co.uk/modernpos/')
  })



  Then('user clicks input email', function()  {
    pom_project_page.getemail()
  })
  

  Then('user clicks input password', function()  {
    pom_project_page.getpassword()
  })

  Then('user click on signin button', function()  {
    
    pom_project_page.getsignbutton()
  
  })