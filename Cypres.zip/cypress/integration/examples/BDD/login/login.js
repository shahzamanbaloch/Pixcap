import { Given ,When, Then, And} from "cypress-cucumber-preprocessor/steps";


Given('I open modernpos website', function()  {
  cy.visit('https://www.techwhizz.co.uk/modernpos/')
  
})



  Then('user clicks input email', function()  {
    cy.get("[name='username']").type('sajjad.sahito60@gmail.com')
  })
  

  Then('user clicks input password', function()  {
    cy.get("[name='password']").type('indus658_morderp')
  })

  Then('user click on signin button', function()  {
    
    cy.get("button#login-btn").click()
    cy.visit('https://www.techwhizz.co.uk/modernpos/store_select.php?redirect_to=')
    cy.get("ul.list-unstyled > li:nth-of-type(1) .store-name").click()
  
  })