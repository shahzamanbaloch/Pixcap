
const url = 'http://nbs-todolist-interview-389909.s3-website.eu-west-2.amazonaws.com/'
Given('The User open Todo List Website', () => {
  cy.visit(url)
});


// this.Given(/^open the "([^""]*)" site$/, async function (url) {
//     cy.visit('');
// });

// Given('open the  site, ()=>){
//     cy.visit('http://nbs-todolist-interview-389909.s3-website.eu-west-2.amazonaws.com/');
// });