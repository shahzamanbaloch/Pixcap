import { Given ,When, Then, And} from "cypress-cucumber-preprocessor/steps";

Given('I open google map', function()  {
    cy.visit('https://www.google.com/maps/place/Gardens+by+the+Bay/@1.2815683,103.8614245,17z/data=!3m1!4b1!4m5!3m4!1s0x31da1904937e1633:0x62099677b59fca76!8m2!3d1.2815683!4d103.8636132')
    cy.get("span[jstcache='129']").should('have.text', 'Gardens by the Bay')
    cy.title().should('eq', 'Gardens by the Bay - Google Maps')
  })

  Then('user zoom in', function()  {
    cy.get('#widget-zoom-in').should('exist').click();
  })

  Then('user zoom out', function()  {
    cy.get('button#widget-zoom-out').should('exist').click();
  })
 